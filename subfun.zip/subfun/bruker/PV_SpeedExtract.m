function [fSpeed,timeStampCa_Plane]=PV_SpeedExtract(confSet)


% PV_SpeedExtract extracts speed and timestamps from photovoltaic speed recording systems.
% This function aligns the extracted speed data with timestamps from calcium imaging data,
% facilitating the analysis of movement alongside neuronal activity across different planes.
%
% Inputs:
% confSet - A struct containing configuration settings and paths for data extraction.
%
% Outputs:
% fSpeed - A matrix containing the processed speed data for each imaging plane.
% timeStampCa_Plane - A matrix containing the timestamps for calcium imaging data for each plane.

% The following commented-out code block was intended for selecting a trial based on directory structure.
% It has been disabled for this version.

% Read XML configuration and trial data.
caTrials=XMLread_SLM(confSet.save_path0,1);

numPlanes=length(confSet.ETL);
TSall=caTrials.FrameTS.relativeTime;
TSplane=caTrials.FrameTS.index;
for iPlane=1:numPlanes
    TSnum(iPlane)=sum(TSplane==iPlane);
end
FrameNum=min(TSnum);

% Extract and align timestamps for each plane based on the minimum frame count.
for iPlane=1:numPlanes
    NeedI=find(TSplane==iPlane);
    NeedI=NeedI(1:FrameNum);
    timeStampCa_Plane(:,iPlane)=TSall(NeedI);
end


% Prepare for processing speed data from voltage recordings.
lastFrame=FrameNum;
vRecRaw=caTrials.vRec{1};


% Begin processing for each imaging plane.
for iPlane=1:numPlanes 
% ---
    vRec=vRecRaw;
    vRecTemp = vRec;
    
    % Delete column 2
    % if deleteColumn2 == 1
    %     vRecTemp = vRecTemp(:,[1 3 4]);
    % end
    
    % Add more working columns
    if size(vRec,2) == 3 % Time, Speed, Cam
        vRec(:,4:12) = NaN; vRec(:,[7 10 11]) = 0;
    end
    if size(vRecTemp,2) == 4 % Time, Speed, Cam, LED
        vRecTemp(:,5:12) = NaN; vRecTemp(:,[7 10 11]) = 0;
    end

    % Calculate sampling frequency from voltage recording and verify against expected rate.
    sampFreq = 1/diff(vRecTemp(1:2,1))*1000;   %%voltage recording sampling time is micro-seconds
    if sampFreq==str2num(caTrials.vConfig.Rate.Text)

    else
       disp('sampleRate of Voltage Recording does not match;');
    end

% Analyze camera TTL pulses to identify frame edges and distinguish between positive and negative TTL scenarios.
    if sum(vRecTemp(:,3)<1)>sum(vRecTemp(:,3)>2)
       IsPositiveTTL=1;
       Temp=-vRecTemp(:,3)+5;
       fallingEdges = LocalMinima(diff(Temp),1,-1)+1; %%TTL pulse, looks like it is negative TTL pulse.
    else
       IsPositiveTTL=0;
       fallingEdges = LocalMinima(diff(vRecTemp(:,3)),1,-1)+1; %%TTL pulse, looks like it is negative TTL pulse.
    end

    % plot(vRecTemp(1:10000,3));hold on;
    % plot(fallingEdges(1:50),vRecTemp(fallingEdges(1:50),3),'r.')
    
    % Indt=find(WhiskerFileID==vRecFileID(t));
    % if ~isempty(Indt)   %% There is possible that some recording are without whisker files recorded.
    if exist('whiskTrial1')
       fW = numel(find(whiskTrial1>0))+1; % Total number of whisk frames actually recorded per trial; +1 because frame 1 is NaN
       fW=min([fW,numel(fallingEdges)]);

    else
       fW=numel(fallingEdges);
    end
    vRecTemp(fallingEdges(1:fW),5) = 1:fW;


    if exist('BehavStruc')
    vRecTemp(fallingEdges(1:fW),13:12+BehavNum)=BehavStruc(Indt).BehData(1:fW,:);
    end
    

    % Add calcium time stamps and frame number
    timeStampCaTrial =  timeStampCa_Plane(:,iPlane)*1000;    %%voltage recording sampling time is micro-seconds
    CaSampleTime=median(diff(timeStampCaTrial));   %%micro-seconds


      % Merge calcium imaging timestamps with voltage recording data, aligning neuronal activity data with movement data
    
    addTime = timeStampCaTrial(1:end);
    addTime(:,2:size(vRecTemp,2)) = NaN;
    vRecTemp = sortrows([addTime; vRecTemp]);  %% Merge Ca signal time and Voltage time togoether
    clear addTime
    
    % fCa = lastFrame(t+1)-(lastFrame(t)+1)+1;  %% # of frames of the trial
    frame = 1;                   %% starting frame Index of the trial
    [~,idx] = intersect(vRecTemp(:,1),timeStampCaTrial(:),'stable');

    if length(idx)<lastFrame+1
       idx(end+1)=idx(end)+length(find(vRecTemp(idx(end)+1:end,1)>=timeStampCaTrial(end)&vRecTemp(idx(end)+1:end,1)<=timeStampCaTrial(end)+CaSampleTime));
    end
    % if fR > 25 NEED TO WORK ON THE MULTIPLANE PART
    for n = 1:lastFrame
            vRecTemp(idx(n):idx(n+1)-1,12) = frame;
            frame = frame + 1;
    end

    % Establish usable trial time
    startCa = min(find(vRecTemp(:,12) == 1));
    endCa = max(find(vRecTemp(:,12) == lastFrame));

    newStart(iPlane) = startCa;
    newEnd(iPlane) = endCa;
    % Crop vRecTemp
    vRecTemp = vRecTemp(newStart(iPlane):newEnd(iPlane), :);
    
     % Finalize speed data processing, averaging speed per frame, and store results in fSpeed.
    vRecTemp(vRecTemp(:,12)==0,:)=[];
    tempSpeed = [];
    tempSpeed = accumarray(vRecTemp(:,12), vRecTemp(:,2), [], @nanmean);
    tempSpeed = tempSpeed(min(vRecTemp(:,12)):end);
    % fSpeed = [fSpeed; tempSpeed];
    fSpeed(:,iPlane)=tempSpeed;

   
end

