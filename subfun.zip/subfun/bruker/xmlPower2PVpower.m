function PVpower=xmlPower2PVpower(xmlPower)

PVpower=(xmlPower-0.5)./0.0025;