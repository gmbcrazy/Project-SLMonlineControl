
%% Automatic excute multiple MarkPoint.xml files within a specific Folder
%Noted that the TimeSeries in PrairieLink should be MarkPoint current
%setting -> Imaging or Zseries Sequence recording of specific frames
%Lu Zhang 2024, developed from Lloyd Russell 2016 PrairieLink_RawDataStream.m


% PrairieLink_RawDataStream
% ========================
% Convert and save raw data on-line
% Lloyd Russell 2016. Optimised on 2017-03-10. Added 'GUI' on 2017-04-11
%
% To do:
% ------
% * Fix first run bug - very first tim e running does not connect to PV
% * Header could be improved by containing bitdepth, and number of channels
%
% File header:
% ------------
% First 2 blocks of output file will contain the following information:
% - pixelsPerLine
% - linesPerFrame




% callback function
function PV_LinkExcuteFolder(ProcessFolder,RandomDelayInterval,Repetition,maxFrame,BreakPointFrame)
    
    MarkPointList=dir([ProcessFolder 'SingleP\*Point*.xml']);
    MarkPointGPL=dir([ProcessFolder 'SingleP\*.gpl']);

    if length(MarkPointGPL)>1
       disp('Multiple .gpl files are found')
       return
    elseif isempty(MarkPointGPL)
       disp('No .gpl files are found')
       return

    else
       disp('1 gpl file to define all single points were found')
    end

    if isempty(MarkPointList)
       disp('No .xml files are found')
       return
    else
       disp([num2str(length(MarkPointList)) ' MarkPoint.xml files were found'])
    end


    InterTrialDelay = random('uniform',RandomDelayInterval(1),RandomDelayInterval(2),Repetition,length(MarkPointList));

%     pl.SendScriptCommands('-LoadMarkPoints F:\LuSLMOnlineTest\02152024\WriteFileUpdate3\GPL.gpl');
%     pl.SendScriptCommands('-LoadMarkPoints F:\LuSLMOnlineTest\02152024\WriteFileUpdate3\Point5.xml');



    pl = actxserver('PrairieLink.Application');
    pl.Connect();
    pl.SendScriptCommands(['-SetSavePath ' ProcessFolder]);
    pl.SendScriptCommands('-DoNotWaitForScans');
    pl.SendScriptCommands('-LimitGSDMABufferSize true 100');
%     pl.SendScriptCommands('-StreamRawData true 50');   
    pl.SendScriptCommands('-StreamRawData true 50');
    pl.SendScriptCommands('-fa 1');  % set frame averaging to 1

    samplesPerPixel      = pl.SamplesPerPixel();
    pixelsPerLine        = pl.PixelsPerLine();
    linesPerFrame        = pl.LinesPerFrame();
    totalSamplesPerFrame = samplesPerPixel*pixelsPerLine*linesPerFrame;
    % yaml = ReadYaml('settings.yml');
    % flipEvenRows         = yaml.FlipEvenLines;  % toggle whether to flip even or odd lines; 1=even, 0=odd;
    flipEvenRows         = 1;  % toggle whether to flip even or odd lines; 1=even, 0=odd;
    % get file name
    baseDirectory = pl.GetState('directory', 1);
    tSeriesName   = pl.GetState('directory', 4);
    tSeriesIter   = pl.GetState('fileIteration', 4);
%     tempIter=num2str(tSeriesIter)
    tSeriesIter   = sprintf('%0.3d', str2double(tSeriesIter));

    pl.SendScriptCommands(['-LoadMarkPoints ' MarkPointGPL.folder '\' MarkPointGPL.name] );

    tSeriesIterID=str2num(tSeriesIter);
%     tSeriesIter   = sprintf('%0.3d', str2double(tSeriesIterID))


for iRep=1:Repetition
    StimList=randperm(length(MarkPointList));  %%Randomized the MarkPoint Stimulation Order
    for jxml=1:length(MarkPointList) %%Randomized the MarkPoint Stimulation Order
        ixml=StimList(jxml);
    % flipEvenRows         = 0;  % toggle whether to flip even or odd lines; 1=even, 0=odd;
      close all
      BreakYet=0;
      FlushYet=0;
         pl.SendScriptCommands(['-LoadMarkPoints ' MarkPointList(ixml).folder '\' MarkPointList(ixml).name] );
         filePath      = [baseDirectory, filesep, tSeriesName '-' tSeriesIter]
    % display file name
         completeFileName = [filePath MarkPointList(ixml).name(1:end-4)];
%     decoration = repmat('*', 1, length(completeFileName));
% %     disp([decoration; completeFileName; decoration])
%     handles.FileNameText.String = completeFileName;
%     handles.StartButton.BackgroundColor = [.8 .8 .8];
         pause(0.2);

    % open binary file for writing
         fileID = fopen([completeFileName '.bin'], 'wb');
    % write file header
%          fwrite(fileID, pixelsPerLine, 'uint16');
%          fwrite(fileID, linesPerFrame, 'uint16');

    % flush buffer
         flushing = 1;
         while flushing
            [samples, numSamplesRead] = pl.ReadRawDataStream(0);
            if numSamplesRead == 0
                flushing = 0;
            end
         end

    % start the current t-series
          pl.SendScriptCommands('-TSeries');

    % initialise state variables, buffer, and counters/records
         running        = 1;
         started        = 0;
         loopCounter    = 1;
         totalSamples   = 0;
         framesCounter  = 0;
         frameNum       = 0;
         buffer         = [];
         allSamplesRead = [];
         msg            = [];
         loopTimes      = [];
         droppedData    = [];

    % preview image window (only use for debugging!)
         preview = 1;
         if preview
            figure(2);
            subplot(2,2,1)
            Image = imagesc(zeros(linesPerFrame, pixelsPerLine));
            FrameCounter = title('');
            axis off; axis square; axis tight;
         end

    % get data, do conversion, save to file
        while running   
        % start timer
              tic;    

        % get raw data stream (timer = ~20ms)
              [samples, numSamplesRead] = pl.ReadRawDataStream(0); 

        % append new data to any remaining old data
               buffer = [buffer samples(1:numSamplesRead)];

        % extract full frames
        numWholeFramesGrabbed = floor(length(buffer)/totalSamplesPerFrame);
        IncludedInd=1:numWholeFramesGrabbed*totalSamplesPerFrame;
        toProcess = buffer(IncludedInd);

        % clear data from buffer
%         buffer = buffer((numWholeFramesGrabbed*totalSamplesPerFrame)+1:end);
        buffer(IncludedInd)=[];
        RestFrameN=length(buffer)/numWholeFramesGrabbed/totalSamplesPerFrame;



        % process the acquired frames (timer = ~5ms)

          if numWholeFramesGrabbed > 0
                for i = 1:numWholeFramesGrabbed
                      if started == 0
                        started = 1;
                      end

                % get single frame
                      frame = toProcess(((i-1)*totalSamplesPerFrame)+1:(i*totalSamplesPerFrame));

                % process the frame (C++ mex code)
                      frame = PrairieLink_ProcessFrame(frame, samplesPerPixel, linesPerFrame, pixelsPerLine, flipEvenRows);

                % save processed frames to file
                % increment frame counter
                      frameNum = frameNum + 1;
                      if BreakYet==0&&frameNum>BreakPointFrame
                         frameNum=frameNum-1;
                         BreakYet=1;
                         buffer=[];
                         [samples, numSamplesRead] = pl.ReadRawDataStream(0);                         
                         break;
                      end

                      fwrite(fileID, frame, 'uint16');
                % debugging: preview plot
                      if preview
                         Image.CData = frame';
                         FrameCounter.String = msg;
                         pause(0.00001);
                     end
               end
          end

        % display progress
%         fprintf(repmat('\b', 1, length(msg)));  % delete previous 'message'
             msg = ['Frame: ' num2str(frameNum) ', Loop: ' num2str(loopCounter) ', Sample: ' num2str(totalSamples)];
%         fprintf(msg);
%         handles.ProgressText.String = msg;
%         drawnow

        % increment counters
              framesCounter = framesCounter + numWholeFramesGrabbed;
              loopCounter = loopCounter + 1;
              totalSamples = totalSamples + numSamplesRead;
              allSamplesRead(end+1) = numSamplesRead;
              loopTimes(end+1) = toc;

        % test for dropped data
              droppedData(end+1) = pl.DroppedData();
              if droppedData(end)
                 fprintf(2, ['\n!!! DROPPED DATA AT FRAME ' num2str(framesCounter) ' !!!\n'])
                 fprintf(msg)
              end



%         Visulize samples recorded in each loop, only use for debugging!Lu Zhang


        % exit loop if finished (if no data collected for previous X loops)
%         if started && loopCounter > 150 && sum(allSamplesRead(end-139:end)) == 0
%             running = 0;
%         end
%             if started && framesCounter >= maxFrame
%                  running = 0;
%             end
            if started && frameNum >= maxFrame
                 running = 0;
            end
         if preview
            figure(2);
            subplot(2,2,2)
            hold on;plot(loopCounter,numWholeFramesGrabbed,'r.')
%             hold on;plot(loopCounter,numSamplesRead,'r.')

%             set(gca,'ylim',[0 maxFrame+3],'ytick',[0 maxFrame])
            ylabel('numWholeFramesGrabbed')

            subplot(2,2,3)
            hold on;plot(loopCounter,RestFrameN,'b.')
            ylabel('Rest Buffer length')
            subplot(2,2,4)
            if exist('numWholeFramesGrabbed')
               hold on;plot(loopCounter,frameNum,'g.')
               hold on;plot(loopCounter,framesCounter,'r.')
%                plot(loopCounter,BreakPointFrame,'y.')
            end
            set(gca,'ylim',[0 maxFrame+3],'ytick',[0 maxFrame])
            ylabel('Frame # recorded')
         end
%             if BreakYet&&started && loopCounter > 10 && sum(allSamplesRead(end-9:end)) == 0   % Keep running but clean buffer during no-data period (such as MarkPoints) but recording not finished yet (if no data collected for previous Y loops)
% %                  buffer=[];
%                running = 1;
%                [samples, numSamplesRead] = pl.ReadRawDataStream(0);
%             end

            if started && loopCounter > 150 && sum(allSamplesRead(end-119:end)) == 0   % Keep running but clean buffer during no-data period (such as MarkPoints) but recording not finished yet (if no data collected for previous Y loops)
               running=0;
            end
         end

    % clean up
         fclose(fileID);
         disp(['Pause ' num2str(InterTrialDelay(iRep,ixml)) 's for next trial'])
         pause(InterTrialDelay(iRep,ixml));

    %% Update file name for next recording trial
         tSeriesIterID=tSeriesIterID+1;
         tSeriesIter   = sprintf('%0.3d', tSeriesIterID);



    end

end


    pl.Disconnect();
    delete(pl);

end
