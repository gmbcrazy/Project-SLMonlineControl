function prairier_link()
pl = actxserver('PrairieLink64.Application');


%pl = actxGetRunningServer('PrairieLink.Application');
pl.Connect("10.168.11.123")
x



