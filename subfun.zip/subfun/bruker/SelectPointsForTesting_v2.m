function [TestPoints, TestLaserLevels] = SelectPointsForTesting(SLMRes, sampleN, SLMTestParam, ZTestNum)
    % Get the size of SLMRes and sampleN
    [N, L] = size(SLMRes);
    
    % Generate the PointsListAll and LaserListAll in a vectorized manner
    [iPoints, iTrials, iLasers] = ndgrid(1:N, 1:SLMTestParam.TerminalTrialN, 1:L);
    PointsListAll = iPoints;
    LaserListAll = iLasers;
    
    % Initialize the list of points and laser levels to test
    TestPoints = [];
    TestLaserLevels = [];
    
    % Iterate through all laser levels from low to high
    for iLaser = 1:L
        for iPoint = 1:N
            % Skip points that have already been marked as done or succeeded at a lower level
            if any(SLMRes(iPoint, 1:iLaser-1) == 1 & sampleN(iPoint, 1:iLaser-1) >= SLMTestParam.TerminalTrialN)
                continue;
            end
            % If SLMRes is 0 and sampleN is >= ExcludeTrialN, move to next laser level
            if SLMRes(iPoint, iLaser) == 0 && sampleN(iPoint, iLaser) >= SLMTestParam.ExcludeTrialN
                continue;
            end
            % If SLMRes is 1 and sampleN is < TerminalTrialN, this test is a priority
            if SLMRes(iPoint, iLaser) == 1 && sampleN(iPoint, iLaser) < SLMTestParam.TerminalTrialN
                TestPoints = [TestPoints; iPoint];
                TestLaserLevels = [TestLaserLevels; iLaser];
            % If SLMRes is 0 and sampleN is < ExcludeTrialN, we also need to test this point at the same laser level
            elseif SLMRes(iPoint, iLaser) == 0 && sampleN(iPoint, iLaser) < SLMTestParam.ExcludeTrialN
                TestPoints = [TestPoints; iPoint];
                TestLaserLevels = [TestLaserLevels; iLaser];
            end
        end
    end
    
    % Combine TestPoints and TestLaserLevels into a single list for easier selection
    Tests = [TestPoints, TestLaserLevels];
    
    % Prioritize tests based on laser level to ensure proper coverage and continue testing until all required tests are done
    remainingTests = [];
    for iLaser = 1:L
        idx = find(Tests(:, 2) == iLaser);
        if ~isempty(idx)
            remainingTests = [remainingTests; Tests(idx, :)];
        end
    end
    
    % Select the first ZTestNum points to test, or all if there are fewer than ZTestNum
    if size(remainingTests, 1) > ZTestNum
        remainingTests = remainingTests(1:ZTestNum, :);
    end
    
    % Split back into TestPoints and TestLaserLevels
    TestPoints = remainingTests(:, 1);
    TestLaserLevels = remainingTests(:, 2);
end
