function SLMTable=SLMtargetAnalysis(ProcessFolder, Param,GlobalSavePath,SessinInfo, TargetZ)



% 
PreImgN=Param.PreImgN; %%Frame num. before imaging start to show the previous imaging data.
PreSLMFrameN=Param.PreSLMFrameN; %Frame num. before SLM to calculate baseline level
PostSLMFrameN=Param.PostSLMFrameN; %Frame num. after SLM to calculate response level
TrialRepTh=Param.TrialRepTh; %%Minimal num. of trials to quantify SLM response
DistTh=Param.DistTh;%%Maximal distance by pixels considered between target cell and SLM target center.

[AnimalInfo, DateInfo] = extractAnimalIDandDate(ProcessFolder);
SurgeryInfo = readtable('\\nimhlabstore1.nimh.nih.gov\UFNC\FNC2\Zhang\Mouse\SurgeryTable.xlsx');

[~,ic]=ismember(AnimalInfo,SurgeryInfo.MouseID)
if ~isempty(ic)
   Genotype=SurgeryInfo.Genotyping(ic);
   Virus=SurgeryInfo.Virus(ic);
else
   Genotype={'NA'};
   Virus={'NA'};
end

if exist([ProcessFolder 'Data\'])
   DataFolder=[ProcessFolder 'Data\'];
else
   DataFolder=ProcessFolder;   
end
% MP=load([ProcessFolder 'SLMIncludedIndFromIscell.mat']);
% SingP=[DataFolder 'SingleP\GPL.gpl']
SinglePSTHFolder=[DataFolder 'SinglePSTH\']
ResultFolder=SinglePSTHFolder;
mkdir(SinglePSTHFolder);

% SingPZ=[0 0 50 50 50 100 100]
BinFile=dir([DataFolder '*TSeries*GPoint*.bin']);
BinTable = PointLaser_files(BinFile);
BinTable=removevars(BinTable,{'Laser'});

TiffTable = ExpInfoMultiTiffFolder(DataFolder);
if ~isempty(SessinInfo)
SessInfo=readtable([ProcessFolder 'SessionInfo.xlsx']);
SessInfo=removevars(SessInfo,{'TotalRepetition'});
SessInfo=removevars(SessInfo,{'Power'});
SessInfo.Properties.VariableNames{'Session'} = 'FileID';
% SessInfo.Properties.VariableNames{'Power'} = 'Laser';
% SessInfo.Properties.VariableNames{'TotalRepetition'} = 'totalRepetitions';
% SessInfo.Properties.VariableNames{'Session'} = 'FileID';
DataList = outerjoin(TiffTable, SessInfo, 'Keys', 'FileID', 'MergeKeys', true);
DataList(isnan(DataList.totalRepetitions),:)=[];
elseif exist('BinTable')

       if ~isempty(BinTable)
          DataList = outerjoin(TiffTable, BinTable, 'Keys', 'FileID', 'MergeKeys', true);
       else
          DataList=TiffTable;
       end

else



end

Param.PostImgN=median(DataList.totalRepetitions);


[NeuronPos3D,NeuronPos3DRaw,CaData,CaDataPlane,stat,yaml]=Suite2pMultiPlaneROIToXYZ(DataFolder,DataList.FileID(10));
[cellIDMap,CellPixCount,MedCenter,cellBoundary]=Suite2pCellIDMapFromStat(CaData.statCell,[yaml.FOVsize_PX yaml.FOVsize_PY]);
% [cellIDMap,CellPixCount,MedCenter,cellBoundary]=Suite2pCellIDMapFromStat(stat,FovSize)
% cellBoundary = CellIDMap2Boundary(cellIDMap);
yaml.Zdepth_ETL=unique(round(yaml.Zdepth_ETL));
%% In this recording file, I forgot take single image to identify the GPL Position. 
resultPaths = findAllFiles([ProcessFolder], 'All.gpl');

if exist([ProcessFolder 'SLMIncludedIndFromIscell.mat'])
    MPtemp=load([ProcessFolder 'SLMIncludedIndFromIscell.mat']);
    if  isfield(MPtemp,'Pos3DNeed')
       MP3D=MPtemp.Pos3DNeed;
   else
       MP3D=MPtemp.Pos3Dneed;
   end
    [~,LocB]=ismember(ceil(MP3D(:,3)),ceil(yaml.scan_Z(1)+yaml.Zdepth_ETL));
    MP3D(:,3)=yaml.Zdepth_ETL(LocB);
    for i=1:size(MP3D,1)
         MPName{i}=['Point ' num2str(i)];
    end
elseif ~isempty(resultPaths)
    gplFile=resultPaths{1};
    tbl=gpl2Table(gplFile);
    % XYPos=gplXYtoPixel(tbl,yaml);
    [MPPos,Z]=gplXYtoPixel(tbl,yaml);
    MPName=tbl.Name;
    MP3D=[MPPos yaml.Zdepth_ETL(Z(:,2))'];
else
    disp('No MarkPoint is available')
end

%% Load Suite2p
% suite2pPath = findAllFolders(DataFolder, 'suite2p');
suite2pPath = findAllFolders(DataFolder, 'suite2p');
    
    % If only one Suite2P folder is found, use it
    if length(suite2pPath) == 1
        suite2pPath = suite2pPath{1};
    elseif length(suite2pPath) > 1
        for isuite=1:length(suite2pPath)
            tempL(isuite)=length(suite2pPath{isuite});
        end
        [~,i1]=min(tempL);
        suite2pPath=suite2pPath{i1};
    else
        disp(['No suite2p processed folder is found in ' LoadPath])
        return
    end


CombinedSuite2p= findAllFiles([suite2pPath 'combined\'], 'Fall.mat');

if length(CombinedSuite2p)==1
Fall=load(CombinedSuite2p{1});
cellInfo=Suite2pCellInfo(Fall);
end


if sum(DataList.totalRepetitions)~=size(Fall.F,2)
   disp('Warning!!! Size of Frames from Suite2p does NOT match tiff nums in Tiff Folders');
end
% SinglePxyz=[];
% SinglePxyz=Pos3DNeed;
Laser=unique(DataList.Laser);
Point=unique(DataList.Point);
Laser(isnan(Laser))=[];
Point(isnan(Point))=[];
% % SinglePxyz=Pos3DNeed(Point,:);
% SLMframe=median(DataList.PostSLMframe)-1;
SLMframe=median(DataList.PostSLMframe);

% DataList.PostSLMframe(1);

% TrialRepTh=4;
% PreImgN=10;
% PostImgN=min(90,median(DataList.totalRepetitions));
PostImgN=median(DataList.totalRepetitions);

% PostSLMFrameN=3;
% PreSLMFrameN=20;


SessInfoNeed=DataList;
LastFrame=cumsum([SessInfoNeed.totalRepetitions]);
FirstFrame=[1;LastFrame(1:end-1)+1];
clear IndStart IndEnd
for i=1:length(FirstFrame)
    IndStart(i,1)=FirstFrame(i)-PreImgN;
    IndEnd(i,1)=FirstFrame(i)+PostImgN-1;
end

SessInfoNeed.FirstFrame=FirstFrame;
SessInfoNeed.PreFrame=IndStart;
SessInfoNeed.PostFrame=IndEnd;
SessInfoNeed(SessInfoNeed.PreFrame<0,:)=[];
NonSLMInd=find(SessInfoNeed.Laser==0&SessInfoNeed.Point>0);
SLMInd=find(SessInfoNeed.Laser(:,1)>1&SessInfoNeed.Point>0);     %% Point  = 0 refers no SLM, < 0 refers to Group Stimuli. 
MarkPoint=unique(SessInfoNeed.Point(SLMInd));

SLM3D=MP3D(Point,:);
SLMName=MPName(Point);


%% Plot SLM target location, Cell ROIs with mean imaging. 
colorCell=jet(length(cellBoundary));
colorCell = colorCell(randperm(length(cellBoundary)),:);
MeanImgClim=[0 1];


figure;
% Img=AmpNormalize(permute(double(CaData.PlaneMeanImg),[2 1 3]),[1 99]);
Img=AmpNormalizeDim(permute(double(CaData.PlaneMeanImg),[2 1 3]),3,[1 99]);
MultiMatrix3DPlotZ(Img,yaml.Zdepth_ETL,0.9);
caxis(MeanImgClim);
Radius=4;
colormap(gray);
set(gca,'xlim',[0 512],'ylim',[0 512],'zlim',yaml.Zdepth_ETL([1 end]),'View',[64 24],'zDir','reverse');
 % plotCellCenter3D(SinglePxyz(:,:,iPoint), Radius, [0 1 0],1.5);
% plotCellCenter3D(NeuronPos3D, Radius, [0 1 0],1);
plotCellCenter3D(SLM3D, Radius, [0 1 0],1);
labelCellCenter(SLM3D, SLMName,[0 1 0])
plotCellBoundary3D(cellBoundary, NeuronPos3D(:,3),colorCell,0.5)
% labelCellCenter(NeuronPos3D, 1:size(NeuronPos3D,1),colorCell)
papersizePX=[0 0 16 length(yaml.Zdepth_ETL)*12];
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'PaperPosition',papersizePX,'PaperSize',papersizePX(3:4));
saveas(gcf,[ResultFolder '3DCell'],'png');
saveas(gcf,[ResultFolder '3DCell'],'fig');


CellID=1:size(NeuronPos3D,1);

figure;
% labelCellCenter(NeuronPos3D(I,[2 1]), CellID(I),colorCell(I,:));
MultiPlanes2DShow(Img, [], NeuronPos3D, CellID,yaml.Zdepth_ETL, colorCell, MeanImgClim)
papersizePX=[0 0 length(yaml.Zdepth_ETL)*11 10];
set(gcf, 'PaperUnits', 'centimeters');
set(gcf,'PaperPosition',papersizePX,'PaperSize',papersizePX(3:4));
saveas(gcf,[ResultFolder '2DCell'],'png');
saveas(gcf,[ResultFolder '2DCell'],'fig');


%% Fine Cell ROI close to SLM target, as responsive cell 
[SLMtarget,SLMtargetCellDist]=SLMtargetMatchCell(SLM3D,NeuronPos3D,DistTh);
LaserG=Laser;
deltaFoF=F2deltaFoF(Fall.F,Fall.Fneu,Fall.ops.fs);

NData={deltaFoF'};
Nlabel={'DeltaF'};
planeG=unique(cellInfo.iplane);
for iplane=1:length(planeG)
    PlaneC(iplane)=max(find(cellInfo.iplane==planeG(iplane)));
end

iscell=find(Fall.iscell(:,1)==1);
P.xLeft=0.1;        %%%%%%Left Margin
P.xRight=0.1;       %%%%%%Right Margin
P.yTop=0.02;         %%%%%%Top Margin
P.yBottom=0.1;      %%%%%%Bottom Margin
P.xInt=0.01;         %%%%%%Width-interval between subplots
P.yInt=0.03;         %%%%%%Height-interval between subplots

PlaneNumStart=[1 PlaneC(1:end-1)+1];
colorLaser=colormap("jet");
colorLaser=colorLaser(1:size(colorLaser,1)/length(LaserG):size(colorLaser,1),:);
close


%% Ave SLM targets illustration
close all
ResultFolderCell=[ResultFolder 'SLMtarget\'];
mkdir(ResultFolderCell);
% PostSLMFrameN=3;
% PreSLMFrameN=30;
nPlane=length(CaDataPlane);

SLMTable = [];
LaserG=setdiff(LaserG,0);
for jCell=1:length(SLMtarget)
    iCell=SLMtarget(jCell);
    if iCell<0
       SLMTable(end+1,:) =  [Point(jCell) 0 0 0 1 0 PreSLMFrameN PostSLMFrameN 0 0 0];
       continue;
    end
    figure;

    for iData=1:length(NData)

        TempData=double(NData{iData}(iscell(iCell),:));
        TempData=AmpNormalize(TempData,[0 100]);

            for iLaser=1:length(LaserG)
            % for iLaser=1:8
                if LaserG(iLaser)==0
                   I2=find(SessInfoNeed.Laser(:,1)==LaserG(iLaser));      
                else
                   I2=find(SessInfoNeed.Laser(:,1)==LaserG(iLaser)&SessInfoNeed.Point==MarkPoint(jCell));
                end

                I3=I2;
                if length(I3)>=TrialRepTh
                   preSLM=[];
                   postSLM=[];
                   for iSess = 1:length(I3)
                       for iS=1:length(SLMframe)
                       TempI1=SessInfoNeed.FirstFrame(I3(iSess))+SLMframe(iS)-1;    
                       % TempI1=SessInfoNeed.FirstFrame(I3(iSess))+SLMframe(iS)-1;
                       PostStim=TempI1:TempI1+PostSLMFrameN-1;
                       PreStim=TempI1-PreSLMFrameN:TempI1-1;


                       preSLM=[preSLM;TempData(PreStim)'];
                       postSLM=[postSLM;TempData(PostStim)'];
                       end
                   end

                   [~,p,~,t]=ttest2(postSLM,preSLM,'Tail','right');
                   ChangePerc=100*(mean(postSLM)-mean(preSLM))/mean(preSLM); 
                   SLMTable(end+1,:) =  [Point(jCell) iCell LaserG(iLaser) ChangePerc p length(I3) PreSLMFrameN PostSLMFrameN t.tstat t.df t.sd ];

                   


                end

                if ~isempty(I3)
                   tempPSTH=[];

                   for iSess = 1:length(I3)
                       TempI=SessInfoNeed.PreFrame(I3(iSess)):SessInfoNeed.PostFrame(I3(iSess));
                       tempPSTH(:,iSess)=TempData(TempI);

                   end
                   PSTHLaser(:,iLaser)=squeeze(mean(tempPSTH,2));
                   subplotLU(1,length(NData),1,iData,P);hold on
                   BaseLine=repmat(mean(tempPSTH(1:PreImgN,:),1),size(tempPSTH,1),1);
                   tempPSTH=tempPSTH-BaseLine;

                   error_area(1:size(tempPSTH,1),mean(tempPSTH,2),ste(tempPSTH')',colorLaser(iLaser,:),0.4,'-',0.5);
                   set(gca,'ylim',[-0.02 0.12]);
                   hold on;
                   for jf=1:length(SLMframe)
                   plot(PreImgN+[SLMframe(jf) SLMframe(jf)],[-0.1 0.3],'k:');
                   end

                   set(gca,'xlim',[0 PreImgN+0.5+PostImgN] ,'xtick',[0 PreImgN+0.5 PreImgN+0.5+PostImgN],'xticklabel',{['-' num2str(PreImgN)] '0' num2str(PostImgN)})
                   xlabel(Nlabel{iData})
                   set(gca,'tickdir','out')
                   set(gca,'ylim',[-0.2 0.6],'ytick',[-0.2:0.2:0.6]);
                   title(['MP' num2str(num2str(MarkPoint(jCell))) 'Cell' num2str(iCell)]);

                end

            end
     colormap(colorLaser);   
     b = colorbar;
     set(b,'position',[0.92 0.2 0.01 0.5]);
     ylabel(b, 'PV power');
     set(b,'ytick',[1:length(LaserG)]/length(LaserG),'yticklabel',LaserG);

    end
     papersizePX=[0 0 length(NData)*8 5 ];
     set(gcf, 'PaperUnits', 'centimeters');
     set(gcf,'PaperPosition',papersizePX,'PaperSize',papersizePX(3:4));
     saveas(gcf,[ResultFolderCell 'SLMTargetMarkPoint' num2str(MarkPoint(jCell))],'png');
     close all


end


SLMTable=array2table(SLMTable,'VariableNames',{'MarkPointID','NeuronID','SLMpower','PercChange','p_value','NumTrials','PreSLMframes','PostSLMframes','t','df','sd'});
ZeroPower=SLMTable.SLMpower==0;
SLMTable(ZeroPower,:)=[];


AnimalID = repmat({AnimalInfo}, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable
Date = repmat({DateInfo}, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable
DataPath=repmat({ProcessFolder}, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable

Genotype=repmat(Genotype, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable
Virus=repmat(Virus, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable


SLMTable.AnimalID = AnimalID; 
SLMTable.Date = Date; 
SLMTable.DataPath = DataPath; 
SLMTable.Genotype = Genotype; 
SLMTable.Virus = Virus; 


SLMTable = movevars(SLMTable, 'Date', 'Before', 1);
SLMTable = movevars(SLMTable, 'Genotype', 'Before', 1);
SLMTable = movevars(SLMTable, 'Virus', 'Before', 1);
SLMTable = movevars(SLMTable, 'AnimalID', 'Before', 1);

writetable(SLMTable,[ResultFolderCell 'SLMtable.xlsx']);
% writetable(SLMTable,[ResultFolderCell 'SLMtable.csv']);
SLMresponse=SLMTable(SLMTable.PercChange>0&SLMTable.p_value<0.05,:);

clear WriteStr;
WriteStr{1}=[num2str(length(unique(SLMresponse.MarkPointID))) ' out of ' num2str(length(unique(SLMTable.MarkPointID))) ' SLM targets respond' ' from ' AnimalInfo '(' Genotype{1,1} ') with Virus ' Virus{1,1}  ' on ' DateInfo];
% xlswrite([ResultFolderCell 'SLMtable.xlsx'],WriteStr,'Conclusion');
if isempty(GlobalSavePath)
GlobalResult=[GlobalSavePath '.txt'];
FID=fopen(GlobalResult,'a');
fprintf(FID, '%s\r\n', WriteStr{1});
fclose(FID);
GlobalTable=[GlobalSavePath '.xlsx'];
updateTable(GlobalTable, SLMTable);
end


