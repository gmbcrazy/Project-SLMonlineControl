function SLMTable=SLMCrossTalkAnalysis(ProcessFolder,Param,GlobalSavePath,SessinInfo,AllCellParam)



% 
PreImgN=Param.PreImgN; %%Frame num. before imaging start to show the previous imaging data.
PreSLMFrameN=Param.PreSLMFrameN; %Frame num. before SLM to calculate baseline level
PostSLMFrameN=Param.PostSLMFrameN; %Frame num. after SLM to calculate response level
TrialRepTh=Param.TrialRepTh; %%Minimal num. of trials to quantify SLM response
DistTh=Param.DistTh;%%Maximal distance by pixels considered between target cell and SLM target center.
PostImgN=Param.PostImgN; %%Frame num. after imaging start to calculate cross-talk
Pth=Param.CrossPth;



[AnimalInfo, DateInfo] = extractAnimalIDandDate(ProcessFolder);
SurgeryInfo = readtable('\\nimhlabstore1.nimh.nih.gov\UFNC\FNC2\Zhang\Mouse\SurgeryTable.xlsx');

[~,ic]=ismember(AnimalInfo,SurgeryInfo.MouseID)
if ~isempty(ic)
   Genotype=SurgeryInfo.Genotyping(ic);
   Virus=SurgeryInfo.Virus(ic);
else
   Genotype={'NA'};
   Virus={'NA'};
end

if exist([ProcessFolder 'Data\'])
   DataFolder=[ProcessFolder 'Data\'];
else
   DataFolder=ProcessFolder;   
end
% MP=load([ProcessFolder 'SLMIncludedIndFromIscell.mat']);
% SingP=[DataFolder 'SingleP\GPL.gpl']
SinglePSTHFolder=[DataFolder 'SinglePSTH\']
ResultFolder=SinglePSTHFolder;
mkdir(SinglePSTHFolder);

% SingPZ=[0 0 50 50 50 100 100]
BinFile=dir([DataFolder '*TSeries*GPoint*.bin']);
BinTable = PointLaser_files(BinFile);
BinTable=removevars(BinTable,{'Laser'});

TiffTable = ExpInfoMultiTiffFolder(DataFolder);
if ~isempty(SessinInfo)
SessInfo=readtable([ProcessFolder 'SessionInfo.xlsx']);
SessInfo=removevars(SessInfo,{'TotalRepetition'});
SessInfo=removevars(SessInfo,{'Power'});
SessInfo.Properties.VariableNames{'Session'} = 'FileID';
% SessInfo.Properties.VariableNames{'Power'} = 'Laser';
% SessInfo.Properties.VariableNames{'TotalRepetition'} = 'totalRepetitions';
% SessInfo.Properties.VariableNames{'Session'} = 'FileID';
DataList = outerjoin(TiffTable, SessInfo, 'Keys', 'FileID', 'MergeKeys', true);
DataList(isnan(DataList.totalRepetitions),:)=[];
elseif exist('BinTable')

DataList = outerjoin(TiffTable, BinTable, 'Keys', 'FileID', 'MergeKeys', true);
else



end

% Param.PostImgN=min([PostImgN,median(DataList.totalRepetitions),]);


[NeuronPos3D,NeuronPos3DRaw,CaData,CaDataPlane,stat,yaml]=Suite2pMultiPlaneROIToXYZ(DataFolder,DataList.FileID(10));
[cellIDMap,CellPixCount,MedCenter,cellBoundary]=Suite2pCellIDMapFromStat(CaData.statCell,[yaml.FOVsize_PX yaml.FOVsize_PY]);
% [cellIDMap,CellPixCount,MedCenter,cellBoundary]=Suite2pCellIDMapFromStat(stat,FovSize)
% cellBoundary = CellIDMap2Boundary(cellIDMap);
yaml.Zdepth_ETL=unique(round(yaml.Zdepth_ETL));
%% In this recording file, I forgot take single image to identify the GPL Position. 
resultPaths = findAllFiles([ProcessFolder], 'All.gpl');

if exist([ProcessFolder 'SLMIncludedIndFromIscell.mat'])
    MPtemp=load([ProcessFolder 'SLMIncludedIndFromIscell.mat']);
    MP3D=MPtemp.Pos3DNeed;
    [~,LocB]=ismember(ceil(MP3D(:,3)),ceil(yaml.scan_Z(1)+yaml.Zdepth_ETL));
    MP3D(:,3)=yaml.Zdepth_ETL(LocB);
    for i=1:size(MP3D,1)
         MPName{i}=['Point ' num2str(i)];
    end
elseif ~isempty(resultPaths)
    gplFile=resultPaths{1};
    tbl=gpl2Table(gplFile);
    % XYPos=gplXYtoPixel(tbl,yaml);
    [MPPos,Z]=gplXYtoPixel(tbl,yaml);
    MPName=tbl.Name;
    MP3D=[MPPos yaml.Zdepth_ETL(Z(:,2))'];
else
    disp('No MarkPoint is available')
end

%% Load Suite2p
suite2pPath = findAllFolders(DataFolder, 'suite2p');
if length(suite2pPath)==1
   CombinedSuite2p= findAllFiles([suite2pPath{1} 'combined\'], 'Fall.mat');
end
if length(CombinedSuite2p)==1
Fall=load(CombinedSuite2p{1});
cellInfo=Suite2pCellInfo(Fall);
end


if sum(DataList.totalRepetitions)~=size(Fall.F,2)
   disp('Warning!!! Size of Frames from Suite2p does NOT match tiff nums in Tiff Folders');
end

Laser=unique(DataList.Laser);
Point=unique(DataList.Point);
Laser(isnan(Laser))=[];
Point(isnan(Point))=[];

SLMframe=median(DataList.PostSLMframe)-1;

PostImgN=min([PostImgN,median(DataList.totalRepetitions),min(SLMframe)]);
Param.PostImgN=PostImgN;

SessInfoNeed=DataList;
LastFrame=cumsum([SessInfoNeed.totalRepetitions]);
FirstFrame=[1;LastFrame(1:end-1)+1];
clear IndStart IndEnd
for i=1:length(FirstFrame)
    IndStart(i,1)=FirstFrame(i)-PreImgN;
    IndEnd(i,1)=FirstFrame(i)+PostImgN-1;
end

SessInfoNeed.FirstFrame=FirstFrame;
SessInfoNeed.PreFrame=IndStart;
SessInfoNeed.PostFrame=IndEnd;
SessInfoNeed(SessInfoNeed.PreFrame<0,:)=[];
NonSLMInd=find(SessInfoNeed.Laser==0&SessInfoNeed.Point>0);
SLMInd=find(SessInfoNeed.Laser(:,1)>1&SessInfoNeed.Point>0);     %% Point  = 0 refers no SLM, < 0 refers to Group Stimuli. 
MarkPoint=unique(SessInfoNeed.Point(SLMInd));

SLM3D=MP3D(Point,:);
SLMName=MPName(Point);


%% Plot SLM target location, Cell ROIs with mean imaging. 
colorCell=jet(length(cellBoundary));
colorCell = colorCell(randperm(length(cellBoundary)),:);
MeanImgClim=[0 1];




CellID=1:size(NeuronPos3D,1);




%% Fine Cell ROI close to SLM target, as responsive cell 
[SLMtarget,SLMtargetCellDist]=SLMtargetMatchCell(SLM3D,NeuronPos3D,DistTh);
LaserG=Laser;
deltaFoF=F2deltaFoF(Fall.F,Fall.Fneu,Fall.ops.fs);

NData={deltaFoF'};
Nlabel={'DeltaF'};
planeG=unique(cellInfo.iplane);
for iplane=1:length(planeG)
    PlaneC(iplane)=max(find(cellInfo.iplane==planeG(iplane)));
end

iscell=find(Fall.iscell(:,1)==1);
P.xLeft=0.1;        %%%%%%Left Margin
P.xRight=0.1;       %%%%%%Right Margin
P.yTop=0.02;         %%%%%%Top Margin
P.yBottom=0.1;      %%%%%%Bottom Margin
P.xInt=0.01;         %%%%%%Width-interval between subplots
P.yInt=0.03;         %%%%%%Height-interval between subplots

PlaneNumStart=[1 PlaneC(1:end-1)+1];
colorLaser=colormap("jet");
colorLaser=colorLaser(1:size(colorLaser,1)/length(LaserG):size(colorLaser,1),:);
close


%% Ave SLM targets illustration
close all
ResultFolderCell=[ResultFolder 'CrossTalk\'];
mkdir(ResultFolderCell);
PostSLMFrameN=3;
PreSLMFrameN=30;

SLMTable = [];
LaserG=setdiff(LaserG,0);


if AllCellParam==1
   SLMtarget=CellID;
end



for iData=1:length(NData)
    clear DataMean DataSte
    for jCell=1:length(SLMtarget)
        iCell=SLMtarget(jCell);
         if iCell<0
            SLMTable(end+1,:) =  [0 0 NaN NaN 0 PostImgN PostSLMFrameN];
         continue;
         end


        TempData=double(NData{iData}(iscell(iCell),:));
        TempData=AmpNormalize(TempData,[0 100]);


      
                I2 = find(SessInfoNeed.totalRepetitions>PostImgN);

                I3=I2;
                if length(I3)>=TrialRepTh
                   PostImg=[];
                   for iSess = 1:length(I3)
                       for iS=1:length(SLMframe)
                       TempI1=SessInfoNeed.FirstFrame(I3(iSess));    
                       % TempI1=SessInfoNeed.FirstFrame(I3(iSess))+SLMframe(iS)-1;
                       PostImgInd=TempI1:TempI1+PostImgN-1;
                       PostImg=[PostImg;TempData(PostImgInd)];
                       end
                   end
                   DataMean(jCell,:)=mean(PostImg,1);
                   DataSte(jCell,:)=ste(PostImg);
                   [r(jCell),p(jCell)]=corr(DataMean(jCell,:)',PostImgInd(:),'rows','pairwise','type','Spearman');
                   SLMTable(end+1,:) =  [iCell r(jCell) p(jCell) length(I3) PostImgN PostSLMFrameN];

                   if p(jCell)<Pth&r(jCell)<0
                      figure;                   
                      subplotLU(1,length(NData),1,iData,P);hold on
                      error_area(1:PostImgN,DataMean(jCell,:),DataSte(jCell,:),[0.1 0.9 0.1],0.4,'-',0.5);
                      set(gca,'ylim',[0 1]);
                     set(gca,'xlim',[0 0.5+PostImgN] ,'xtick',[1 PostImgN],'xticklabel',{[num2str(1)] num2str(PostImgN)})
                        xlabel(Nlabel{iData})
                        set(gca,'tickdir','out')
                        set(gca,'ylim',[0 1],'ytick',[0:0.2:1]);
                         title(['Cell' num2str(iCell)]);
                        papersizePX=[0 0 length(NData)*8 5 ];
                          set(gcf, 'PaperUnits', 'centimeters');
                         set(gcf,'PaperPosition',papersizePX,'PaperSize',papersizePX(3:4));
                        saveas(gcf,[ResultFolderCell 'CrossTalkCell' num2str(iCell)],'png');
                         close all
                   end

                end

    end


end


SLMTable=array2table(SLMTable,'VariableNames',{'NeuronID','SLMpower','PercChange','p_value','NumTrials','PreSLMframes','PostSLMframes','t','df','sd'});
ZeroPower=SLMTable.SLMpower==0;
SLMTable(ZeroPower,:)=[];


AnimalID = repmat({AnimalInfo}, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable
Date = repmat({DateInfo}, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable
DataPath=repmat({ProcessFolder}, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable

Genotype=repmat(Genotype, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable
Virus=repmat(Virus, height(SLMTable), 1);  % Create a cell array with 'SL0524' for each row in SLMTable


SLMTable.AnimalID = AnimalID; 
SLMTable.Date = Date; 
SLMTable.DataPath = DataPath; 
SLMTable.Genotype = Genotype; 
SLMTable.Virus = Virus; 


SLMTable = movevars(SLMTable, 'Date', 'Before', 1);
SLMTable = movevars(SLMTable, 'Genotype', 'Before', 1);
SLMTable = movevars(SLMTable, 'Virus', 'Before', 1);
SLMTable = movevars(SLMTable, 'AnimalID', 'Before', 1);

writetable(SLMTable,[ResultFolderCell 'SLMtable.xlsx']);
% writetable(SLMTable,[ResultFolderCell 'SLMtable.csv']);
SLMresponse=SLMTable(SLMTable.PercChange>0&SLMTable.p_value<0.05,:);

clear WriteStr;
WriteStr{1}=[num2str(length(unique(SLMresponse.MarkPointID))) ' out of ' num2str(length(unique(SLMTable.MarkPointID))) ' SLM targets respond' ' from ' AnimalInfo '(' Genotype{1,1} ') with Virus ' Virus{1,1}  ' on ' DateInfo];
% xlswrite([ResultFolderCell 'SLMtable.xlsx'],WriteStr,'Conclusion');
GlobalResult=[GlobalSavePath '.txt'];
FID=fopen(GlobalResult,'a');
fprintf(FID, '%s\r\n', WriteStr{1});
fclose(FID);
GlobalTable=[GlobalSavePath '.xlsx'];
updateTable(GlobalTable, SLMTable);



